---
name: dashboard-builder
description: Build, extend, or redesign enterprise HTML dashboards (executive, finance/FP&A, sales, HR, marketing, operations, or any department). Use for requests to build a dashboard, create an executive/KPI dashboard, turn a dataset (CSV/JSON/API) into a dashboard, create an HTML reporting interface, or clean up/standardize/modernize an existing dashboard's design and responsiveness.
---

# Dashboard Builder

Build production-quality, self-contained HTML dashboards using a proven minimal-enterprise
design system, department-aware information architecture, and a QA methodology that catches
data and layout bugs before the user does.

One main build pass, one QA/fix pass. Not an endless back-and-forth loop.

## Workflow

**1. Discover** — Ask the questionnaire below as ONE compact set of questions (use a structured
multi-question prompt if your tool supports it; otherwise one numbered list the user answers in
one reply). Skip any question already answered by context. Never ask UX jargon — plain options
with a Recommended pick on each.

**2. Inspect** — Before designing anything: look for an existing dashboard, design system, data
files, or brand assets already in the project. An existing dashboard in the repo is a reference
implementation, not a starting template to overwrite — extract its patterns (tokens, layout
grammar, component classes, filter architecture, chart choices) and reuse what works. Load
`references/design-system.md` now.

**3. Plan internally** — Decide hierarchy, sections, KPIs, filters, charts, tables, responsive
strategy, data model, tokens. Do this yourself from the discovery answers + inspected data; don't
make the user sit through a planning conversation unless information is genuinely missing (e.g.
no data source was ever specified).

**4. Build** — One self-contained HTML file by default (see `assets/dashboard-shell.html` for the
scaffold: tokens, layout grammar, components, chart primitives, filter state, formatting helpers,
mobile rules already wired). Load `references/department-patterns.md` for the chosen department
and `references/chart-selection.md` while building. For Finance/FP&A or any AI-assisted dashboard,
also load `references/agentic-fpa.md` and implement its context, calculation, availability, and
scenario contracts before adding AI narrative.

**5–9. QA and fix** — Functional QA, data QA, responsive/UI QA, fix justified issues, regression
retest. Load `references/qa-checklist.md`, `references/data-integrity.md`, and
`references/responsive-accessibility.md` for this stage. Use `scripts/dashboard-qa.js` if a
browser automation tool (Playwright, Puppeteer, or an MCP browser tool) is available; otherwise
do a manual pass against the same checklist. The dashboard is done when the final pass has no
Critical finding.

Load reference files on demand, not all at once — see "Progressive disclosure" below.

## Discovery questionnaire

Ask these together, each with a Recommended option and room for "Other." Do not require the user
to know UX terminology.

1. **Department** — Corporate Finance/FP&A, Accounting/Controllership, Treasury, Investor
   Relations, Executive/CEO, Sales, Marketing, Operations, HR/People, Product,
   Engineering/Technology, Customer Support, Risk/Compliance/Audit, Supply Chain, Other.
   This changes hierarchy, recommended KPIs, chart types, and density — see
   `references/department-patterns.md`. Never default to finance conventions for a non-finance
   department.

2. **Primary audience** — Executive leadership, department leadership, managers, analysts,
   operational users, external/customer-facing, mixed. Recommend based on department (execs and
   customer-facing audiences → lower density, more explanation; analysts/operational → higher
   density, more tables). Audience drives information density, KPI prominence, table-vs-chart
   balance, and drill-down depth.

3. **Main purpose** (multi-select) — executive health/status overview, performance monitoring,
   actual vs. budget/forecast, trend analysis, operational monitoring, exceptions/risk detection,
   planning, reporting, detailed analysis, combination.

4. **Data source** — existing data already in this project, CSV/Excel/JSON, database, API, ERP
   (SAP/D365/Oracle/etc.), semantic layer/warehouse, "I'll provide data later," or
   demo/prototype data. **Never fabricate real business numbers.** If real data isn't available
   and a prototype is requested, generate clearly-labeled DEMO/SAMPLE data (visible badge on the
   dashboard, not just a code comment) and say so explicitly in your reply.

5. **Branding** — (A) use branding/assets already in this project, (B) user will provide
   logo/colors/font, (C) research the company's official site/design system and derive branding
   — Recommended when web access is available and a real company is named, (D) professional
   neutral enterprise theme, (E) custom branding described in chat. If (C): use official sources
   only, verify colors rather than guessing from a low-quality screenshot, check whether a
   legitimate web-licensed brand font exists before using it (fall back to a high-quality system
   stack otherwise), preserve contrast, record the sources used, never invent brand guidelines.
   Purchasing a custom domain or any paid asset requires separate explicit confirmation — this
   question is about visual branding only.

6. **Visual direction** — Minimal enterprise — Recommended (the reference style, see
   `references/design-system.md`), executive/premium, dense analyst dashboard, modern SaaS,
   traditional corporate, match an existing product, custom.

7. **Theme** — Light + Dark — Recommended, light only, dark only, follow system preference. If
   both, every color must be a semantic token (never a literal hex) so nothing disappears in
   either theme — see the three-state theme contract in `references/design-system.md`.

8. **Interaction level** — basic filters + tabs, interactive charts + filters — Recommended,
   drill-down, advanced analysis, mostly static executive view.

## Non-negotiables

- **Never fabricate real business numbers.** Demo/prototype data must be visibly labeled as such
  on the dashboard itself.
- **Every number is traceable.** If a value can't be verified against the given source, mark it
  UNVERIFIED during QA instead of guessing — see `references/data-integrity.md`.
- **Semantic tokens, not literal colors.** Every color used for text, backgrounds, borders, or
  status must resolve through a CSS variable so light/dark and future re-theming both work.
- **One accent, fixed categorical series order.** Don't reorder or randomly assign chart series
  colors; fix the order once and reuse it everywhere the same category appears.
- **Simplest viable implementation.** Default to plain HTML/CSS/JS, hand-rolled SVG charts, zero
  build step, zero CDN dependency, opens from a single file. Only reach for a charting library or
  framework if the requirements genuinely exceed what hand-rolled SVG can do, and say why.
- **Filters are real state.** A filter change must update every affected KPI, chart, table,
  total, subtotal, and percentage — and leave unaffected metrics untouched. Reset must restore
  the exact original state.
- **Company is global state.** In a multi-company dashboard, changing company must update every
  tab, period label, filter, chart, table, export, source note, AI suggestion, and AI evidence
  package. A company name in the URL or header must never sit above another company's data.
- **Calculations before narrative.** Deterministic finance logic owns aggregation, margins,
  variance, free cash flow, and scenario arithmetic. AI receives the checked result and sources;
  it does not become the calculation engine or fill missing numbers.
- **Four evidence states.** Every value is REAL, DERIVED, MODELED, or UNAVAILABLE. These states
  must be visible wherever confusion is plausible, especially scenarios, Q4 derivations, and
  unsupported cross-company disclosures.
- **Agent context is the UI context.** Dashboard AI receives the selected company, fiscal period,
  tab, supported filters, source references, and visible scenario inputs. Suggested questions are
  generated from that same context.
- **Visual hierarchy over decoration.** The dashboard should answer, in this order: what's
  happening, is it good or bad, why, where to look next. Not every metric is equally prominent.

## Progressive disclosure — which references to load

Don't load every reference for every task. Match to what's actually needed:

| Task | Load |
|---|---|
| New dashboard, any department | `design-system.md`, `department-patterns.md` (relevant section only), `chart-selection.md` |
| Before shipping any dashboard | `data-integrity.md`, `responsive-accessibility.md`, `qa-checklist.md` |
| QA/audit of an existing dashboard (no new build) | `qa-checklist.md`, `responsive-accessibility.md`, `design-system.md` |
| Restyle/standardize an existing ugly dashboard | `design-system.md`, `dashboard-ux-rules.md` |
| Department swap on an existing dashboard | `department-patterns.md` only |
| Finance/FP&A, multi-company, or agentic dashboard | `agentic-fpa.md`, `data-integrity.md`, `qa-checklist.md` |

## Portability

This skill's workflow, questionnaire, and reference files are tool-agnostic — they work the same
in Claude Code, Codex, ChatGPT/Codex IDE, or any harness that supports discovering a `SKILL.md`
with YAML frontmatter and loading files from `references/`, `assets/`, and `scripts/` on demand.
Nothing in the workflow assumes a specific model, IDE, OS, or browser. `scripts/dashboard-qa.js`
targets Playwright because it's the most common browser-automation tool agents have access to;
if unavailable, do the same checklist manually or via whatever browser tool the harness exposes
(the checklist in `references/qa-checklist.md` is framework-agnostic).
