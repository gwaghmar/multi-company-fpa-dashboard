# Chart selection

Pick a chart because it answers the analytical question fastest, not because it looks
impressive. When in doubt, a well-formatted table is a legitimate choice, not a fallback of last
resort.

| Analytical question | Chart | Notes |
|---|---|---|
| How did this change over time? | Line | Direct-label series ends where possible; add a target/guide line or a forward estimate marker if the data supports it. |
| Compare discrete categories | Bar (usually horizontal for long labels, vertical for time-like categories) | Sort by value unless a natural order (e.g. chronological, org hierarchy) matters more. |
| Composition of a whole | Stacked bar, or a donut only when there are ≤5 segments and the total itself matters | Prefer stacked bar once segments exceed ~5 — a donut with 8 slices is unreadable. Never use 3D or exploded variants. |
| Actual vs. target/budget | Variance bar (diverging, favorable one direction/color, unfavorable the other) or a bullet chart | Always pair with the numeric delta, not just the visual gap. |
| What drove the change | Waterfall/bridge | Start and end bars fixed/neutral color; positive and negative drivers use the status tokens, not arbitrary series colors. |
| Relationship between two variables | Scatter | Rare in exec dashboards; usually belongs in an analyst-density view, not the KPI-band level. |
| Funnel/stage progression | Funnel or ordered horizontal bars | Common in sales/marketing; label conversion % between stages, not just stage totals. |
| Exact values, many rows/columns | Table | Sticky header, right-aligned numerics, tabular numerals, a totals row. Also serves as the accessible fallback for any chart. |
| One critical number | KPI/stat tile | Always with a comparison (vs. budget, vs. prior period, % of total) — never a bare number. |
| Geographic distribution | Map only if geography is genuinely the point and there are enough distinct regions to justify it; otherwise a sorted bar by region reads faster | Maps are expensive to build well by hand — default to a bar unless explicitly requested. |

## Avoid

- Pie/donut for more than ~5 categories, or when precise comparison between similar-sized slices
  matters (bars beat pies for that every time).
- More chart types than the dashboard needs — a handful of chart shapes used consistently reads
  as more professional than a different exotic chart on every card.
- 3D, excessive gradient fills, or heavy drop shadows on chart marks — flat fills with the
  token-based series colors read as more "enterprise," not less.
- A chart where a single number or a short table would answer the question faster.

## Series color discipline

Fix the categorical order once (`--series-1` … `--series-5`) and reuse it for the same category
everywhere it appears on the dashboard — a category shouldn't be blue on one tab and orange on
another. Reserve the status tokens (`--positive`/`--negative`/`--warning`) for actual
good/bad/caution meaning (variance direction, severity, alerts) — never repurpose them as
generic categorical colors, and never repurpose a categorical series color to mean "bad" just
because it happens to be reddish.
