# Department-aware dashboard patterns

Information-architecture guidance, not permission to invent data. Recommend the KPIs/charts
below; only actually show a metric when the available data supports it. If a recommended metric
has no data source, say so and either omit it or mark it UNVERIFIED/coming-soon rather than
inventing a value.

For every department: audience and purpose (from discovery Q2/Q3) still override density and
depth. An executive view of any department gets fewer, larger KPIs and more narrative; an
analyst view gets more tables and more filters.

## Corporate Finance / FP&A

KPI band candidates: revenue, gross margin %, operating income/EBITDA, opex, net income, FCF.
Always frame vs. budget and/or prior period — a bare financial number is incomplete here more
than in any other department.

Common sections: actual vs. budget vs. forecast trend, variance bridge/waterfall by driver,
expense breakdown, business-unit/geography comparison, cash and working capital, outlook/guidance.
Recurring analysis: YoY/QoQ, budget variance, forecast accuracy. Fiscal calendar may not be
calendar-year — confirm and label periods accordingly (e.g. "FY26 Q3" not just "Q3").

## Accounting / Controllership

Prioritize: close status/timeline, reconciliation status, journal entry activity, balance sheet
snapshot, AR/AP aging, exceptions and control flags. Density skews toward tables and status
indicators over big decorative KPIs — this audience needs to find the exception, not admire a
trend line. A close-status tracker (days-to-close, tasks remaining) is often the single most
useful KPI-band item.

## Treasury

Prioritize: cash position and liquidity, debt schedule/maturity ladder, interest-rate exposure,
FX exposure and hedge coverage, working capital metrics. Time-based visuals (maturity ladders,
liquidity runway) matter more here than category breakdowns.

## Investor Relations

Prioritize: revenue/EPS vs. consensus or guidance, share price/market cap context (if sourced),
capital returns (dividends, buybacks), analyst/guidance commentary, upcoming disclosure calendar.
Every figure needs a citable source (filing, earnings call, press release) — this audience is
the most exposed to a wrong number becoming public.

## Executive / CEO

Prioritize: company-wide health at a glance — revenue, margin, headcount, top risks/exceptions,
strategic initiative status. Lowest density of any department: 4–6 KPIs, one or two supporting
charts, everything else behind a drill-down or a link to a department-specific dashboard. This
is a status page, not an analysis tool.

## Sales

Prioritize: revenue/bookings, pipeline value and stage distribution, win rate/conversion, quota
attainment, average deal size, sales cycle length, top accounts/reps, trends by
region/product/segment. A funnel or stage-distribution chart is usually the single most useful
non-KPI visual. Attainment (actual vs. quota) needs the same "always show the comparison" rule
as finance budget variance.

## Marketing

Prioritize: spend, leads/MQLs/SQLs, CAC, conversion rate by stage, campaign/channel performance,
ROI/ROAS, funnel drop-off. Channel-comparison bar charts and a funnel are the workhorses; avoid
defaulting to donut charts for channel mix if more than ~4 channels exist — a sorted bar reads
faster.

## Operations

Prioritize: throughput/volume, cycle time, on-time rate, capacity/utilization, quality/defect
rate, cost per unit, exception/incident count. Time-series and control-chart-style visuals (with
a target/threshold band) are common; this department benefits from an explicit
threshold/target line on charts, not just a bare trend.

## HR / People

Prioritize: headcount (current + trend), hiring (open reqs, time-to-fill), attrition/turnover
rate, workforce composition (function, level, tenure, location), engagement/survey scores if
available. Handle any demographic breakdowns carefully — aggregate at a level that doesn't
identify individuals, and don't build a dashboard that exposes small-N groups.

## Product

Prioritize: adoption/activation, active users (DAU/WAU/MAU), retention/churn, feature usage,
NPS/CSAT, release/roadmap status. Cohort-style retention visuals are common here and don't map
cleanly to a generic bar/line — treat as a specialized chart type, build carefully or fall back
to a table.

## Engineering / Technology

Prioritize: uptime/reliability (SLA/SLO attainment), deployment frequency, incident count and
MTTR, backlog/velocity, infrastructure cost. Threshold-based status (green/yellow/red against an
SLO) matters more than raw trend lines.

## Customer Support

Prioritize: ticket volume, first-response/resolution time, CSAT, backlog, SLA attainment,
top issue categories. Volume-over-time plus an SLA-attainment KPI covers most requests; category
breakdown is usually a sorted bar, not a donut, once categories exceed ~5.

## Risk / Compliance / Audit

Prioritize: open findings/issues by severity, remediation status and aging, control test
results, exception trends, upcoming audit/regulatory deadlines. Severity-based color coding
(not just categorical series colors) is expected here — reuse the status tokens
(`--negative`/`--warning`/`--positive`), not the chart series palette, for severity.

## Supply Chain

Prioritize: inventory levels/turns, fill rate, on-time delivery, supplier performance, lead
time, cost trends, disruption/exception flags. Geographic/network visuals are common but
optional — a table of supplier metrics is often more actionable than a map.

## "Other" / unlisted department

Ask 1–2 follow-up questions instead of guessing: what decision does this dashboard support, and
what are the 3–5 numbers this audience checks most often. Build the KPI band from those answers
rather than borrowing another department's list wholesale.
