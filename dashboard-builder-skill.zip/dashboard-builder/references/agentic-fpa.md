# Agentic FP&A dashboard contract

Use this reference for Finance/FP&A, strategic-finance, multi-company, scenario-planning, or AI-assisted dashboards.

## 1. Resolve one context

Create one application context that owns:

- selected company or entity;
- fiscal calendar and semantic period preset;
- active tab or workflow;
- supported product, geography, cost-center, department, and scenario filters;
- source references and data-availability capabilities.

Every KPI, chart, table, export, source note, AI suggestion, and AI request must read this same context. Never keep a company parameter in the URL while rendering another company's data.

Use semantic periods such as `Latest reported quarter`, `Current fiscal YTD`, `Latest complete fiscal year`, and `Rolling four quarters`. Do not reuse fixed quarter indexes across companies with different fiscal calendars.

## 2. Run deterministic finance tools

Calculate before asking the model to explain:

- flow metrics sum across selected periods;
- point-in-time metrics use the latest selected period;
- margins recompute from selected numerators and denominators;
- EPS and per-share measures use an exact filed period unless weighted shares are available;
- variance compares an equal fiscal period and states the basis;
- free cash flow states its formula;
- scenario output comes from visible assumptions and reproducible arithmetic.

The language model is not the source of truth for finance math.

## 3. Apply the four-state evidence model

Label values and outputs as:

- **REAL**: directly filed, imported, or approved source data;
- **DERIVED**: deterministic arithmetic from real source values;
- **MODELED**: scenario, allocation, forecast, or synthetic detail using visible assumptions;
- **UNAVAILABLE**: no governed comparable source exists.

Never silently convert UNAVAILABLE into MODELED. Never present MODELED as company guidance, analyst consensus, an approved budget, or management's plan.

## 4. Enforce capability-aware tabs

Define which sources support each company and tab. Standardized financial facts may support revenue, profitability, variance, balance sheet, cash flow, and capital returns. Product mix, geography, guidance, headcount, FX, and environmental disclosures often require separate sources.

If a tab is unsupported:

- keep the selected company visible;
- explain what is unavailable and why;
- name the source needed to populate it;
- keep Ask AI inside the same availability boundary;
- never fall back to a default company's data.

## 5. Build the FP&A loop

The agentic workflow is:

1. Resolve company, fiscal period, tab, filters, and scenario.
2. Retrieve only matching governed evidence.
3. Run deterministic finance calculations.
4. Check availability, period comparability, source lineage, and evidence state.
5. Produce a concise driver, risk, or decision narrative.
6. Return citations, assumptions, and unavailable fields with the answer.

Suggested questions must change with company and tab. A Revenue tab can ask about revenue change; a Variance tab can ask about favorable and unfavorable movements; a Planning tab can ask which visible assumption drives operating income.

## 6. Planning and scenario rules

A public-company dashboard does not contain an internal budget unless one is explicitly connected. A useful public-data planning scaffold may apply user-visible assumptions to the latest filed baseline, but it must be labeled MODELED throughout.

At minimum, expose:

- base period;
- revenue-growth assumption;
- gross-margin change in percentage points;
- operating-expense growth assumption;
- actual and modeled results side by side;
- scenario export with assumptions and field basis.

Do not call a scenario `forecast`, `guidance`, `budget`, or `AOP` without an approved source for that claim.

## 7. Release audit

Before shipping, test every company across every tab or use a representative matrix that covers every capability state. Verify:

- company name and source agree with the rendered data;
- periods follow each company's fiscal calendar;
- filters update all affected surfaces;
- unsupported disclosures show UNAVAILABLE;
- CSV exports match visible context and field basis;
- AI evidence and suggestion pills match company, tab, period, and scenario;
- actual, derived, modeled, and unavailable states are visually distinct;
- desktop, tablet, and phone layouts remain usable;
- there are no console or API errors.
