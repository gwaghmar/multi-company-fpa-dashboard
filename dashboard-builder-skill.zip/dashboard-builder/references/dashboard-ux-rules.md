# Dashboard UX rules

## Visual hierarchy

Every tab should answer, in order, without the reader hunting: **what's happening → is it good
or bad → why → where to look next.** Concretely:

1. Title/subtitle establishes context and active filter state.
2. KPI band gives the headline numbers, each with a comparison and a color-coded direction.
3. The primary chart shows the trend or breakdown that explains the KPI band.
4. Commentary (if present) states the "so what" in one or two sentences, computed from data —
   never hand-authored prose with numbers baked in that can drift from the actual data.
5. Supporting detail and tables are lowest priority, reached by scrolling or a drill-down click.

Not every metric is equally important. Resist the urge to give every number its own KPI tile —
a KPI band with 12 equally-sized tiles has no hierarchy at all. If a metric doesn't change the
reader's next action, it belongs in a table, not the KPI band.

## Typography scale

Define a small fixed scale and reuse it — don't pick a font size ad hoc per component:

| Role | Example size/weight |
|---|---|
| Dashboard/product title (topbar) | 14px, 650 weight |
| Page/tab title (`h1`/`h2`) | 20–34px, 650 weight, tight letter-spacing |
| Section heading (`card h3`) | 10–11px, 650 weight, uppercase, wide letter-spacing |
| KPI value | 20–24px, 650 weight, tight letter-spacing, tabular numerals |
| KPI label | 9–10px, 600 weight, uppercase, muted color |
| Chart title | same as section heading |
| Table header | 10px, 600 weight, uppercase, muted color |
| Body/commentary text | 12–13.5px, 400–500 weight |
| Caption/metadata/footnote | 10–11px, muted color |

If the brand supplies real typography, map it onto these same roles rather than inventing new
ones. If no verified brand font exists, use a high-quality system stack (e.g.
`-apple-system, "Inter", system-ui, sans-serif` or the OS-native equivalent) — never claim a font
is "official" without a source.

## States every data component needs

Every component that renders data (KPI tile, chart, table) must have explicit behavior for:

- **Loading** — a lightweight skeleton or spinner, not a blank card.
- **Populated** — the normal case.
- **Empty / no results for current filter** — a centered, muted message explaining *why*
  ("No results for the selected quarter and region — try clearing a filter"), not a blank chart
  or a `0` that looks like real data.
- **Unavailable** — the data source doesn't provide this metric at all; say so, don't omit
  silently (a silently-missing KPI looks like a bug, not a scope decision).
- **Error** — the fetch/compute failed; show a retry affordance where practical.

Never let `undefined`, `NaN`, or `Infinity` reach the DOM. Guard every formatter:
`value == null || !isFinite(value) ? emptyState() : format(value)`.

## Number formatting — centralize it

One formatting function per unit type, used everywhere that unit appears. Never format the same
metric two different ways in two different components (a `$45.2M` KPI tile next to a `$45,231`
table cell for the same figure is a bug, not a stylistic choice).

- Currency: pick a consistent scale (K/M/B) per context and state it in the label/subtitle if
  it could be ambiguous. Show 1 decimal place at B scale, 0–1 at M scale.
- Percentages: fixed decimal precision (usually 1), always with a sign on deltas (`+2.3%`,
  `-1.1 pts` — and use "pts" not "%" when the delta is itself a percentage-point change, e.g.
  margin moving from 48% to 50% is "+2.0 pts," not "+2.0%").
- Negative numbers: pick one convention (leading minus, or parentheses for accounting-style
  reports) and use it everywhere; never mix conventions in the same dashboard.
- Dates/fiscal periods: label explicitly if the fiscal calendar differs from the calendar year
  (e.g. "FY26 Q1" for an Oct–Sep fiscal year) — don't assume the reader knows the company's
  fiscal calendar.
- Large counts (headcount, tickets, units): thousands separators, no decimal unless genuinely
  fractional (e.g. average deal size).

## Chart annotation and labeling

- Direct-label chart series where reasonable (label at the line's end) rather than relying
  solely on a separate legend — reduces the eye travel between mark and meaning.
- A single fixed categorical color order, reused across every chart on the dashboard where the
  same category appears (e.g. "Product A" is always series-1, everywhere).
- Annotate real events (an announcement, a guidance change) as markers on trend charts when the
  data supports it — a small flag glyph with a tooltip is more useful than a caption below the
  chart.
- Every chart gets an equivalent accessible table (a toggle, not a separate page) — this also
  makes automated data-integrity QA easier since the table exposes exact values a chart doesn't.

## Disclosure and provenance

When a figure is derived (calculated from other filed/known values rather than sourced directly)
or when data quality has caveats (estimated, as-filed at a different cadence, restated), show a
small disclosure note or info-flag next to it — don't bury the caveat in a footnote no one reads.
This is especially important for anything demo/sample data: the label must be visible on the
dashboard itself, not just in code comments.
