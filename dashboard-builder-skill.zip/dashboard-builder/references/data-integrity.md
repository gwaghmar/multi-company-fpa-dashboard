# Data integrity rules

This is mandatory for both the initial build and any QA pass on an existing dashboard.

## Never fabricate

Real business numbers must trace to an actual source (a provided dataset, file, API, or
document). If a value is requested but no source supports it, do not invent a plausible-looking
number — say it's unavailable, or if the user explicitly wants a prototype/demo, generate data
that is **visibly labeled** DEMO/SAMPLE on the dashboard itself (a badge near the title or in the
footer, not just a code comment) so it can never be mistaken for real figures downstream.

## Trace every displayed value

For every KPI, chart series, table cell, total, subtotal, percentage, ratio, or variance:

1. Identify the exact source field(s) it's computed from.
2. Recompute it by hand (or with a quick script) from the raw source and confirm it matches.
3. If it can't be verified against the given source, label it **UNVERIFIED** in your QA report
   rather than guessing or silently shipping it.

## Checks to run

- **Nulls/invalid**: no `null`, `undefined`, `NaN`, or `Infinity` reaches the rendered page.
  Every formatter should guard: unformattable input → an explicit empty/unavailable state, never
  a literal "NaN" or "undefined" string on screen.
- **Blank/missing**: a metric silently absent from a card that other similar cards have present
  is a bug unless it's an intentional per-department/per-filter omission — call it out either
  way.
- **Duplicated data**: the same record or value counted twice (e.g. a table row appearing twice,
  or a total that double-counts a category that appears in two groupings).
- **Stale values**: after a filter change, re-render, or tab switch, confirm no component is
  still showing a value computed under the *previous* filter/tab state. Test by switching
  filters/tabs repeatedly, not just once.
- **Totals and subtotals**: category/segment values sum exactly to their stated total (within
  float rounding tolerance, not a material gap). If they don't, that's a Critical finding.
- **Percentages and ratios**: recompute independently from the same base values shown elsewhere
  on the dashboard; a displayed percentage that doesn't match `part/whole` computed from the
  displayed part and whole is a bug.
- **YoY/QoQ and variance**: recompute the delta from the two period values shown; check both the
  magnitude and the sign.
- **Sign conventions**: negative numbers, "unfavorable" variances, and "down" deltas use one
  consistent convention throughout — verify a red/negative-colored value is actually negative in
  the underlying data, not just styled that way by accident.
- **Rounding**: displayed precision should be consistent for a given metric across every place
  it appears; a rounding difference between two components showing "the same" figure (e.g. a KPI
  tile computed one way and a narrative sentence computed a slightly different way) is a real
  defect class — see the note on divergent bases below.
- **Units**: $ vs. % vs. count vs. bps, and scale (K/M/B, or raw units), must be unambiguous
  and correct at every occurrence.

## Cross-component agreement

If the same metric appears in more than one place (a KPI tile and a chart tooltip; a chart and
its accessible table; a headline number and a narrative sentence describing it), the values must
agree exactly. When they don't, the most common root cause is that the two places are computing
from **different legitimate bases** (e.g. a cash-flow-statement figure vs. an equity-note
trade-date figure for the same nominal metric) rather than one simply being wrong — identify
which base each place actually uses, then either unify them onto one base or label the
difference explicitly so a reader isn't misled by an unexplained gap.

## Filter contract (test every combination, not just one)

When a filter changes:

- Every KPI, chart, and table that the filter logically affects must update.
- Totals, subtotals, percentages, and variances must recalculate from the new filtered set, not
  be patched incrementally from the old ones.
- Metrics genuinely unaffected by the filter (e.g. a point-in-time disclosure that isn't
  period-filtered) must **not** change — and should say so in their label if a reader might
  otherwise expect them to move with the filter.
- Clearing/resetting must restore the exact original (default) state, not an empty or
  partially-reset one.
- Switching filters repeatedly (A → B → A, or several filters in sequence) must not leave any
  stale value from an intermediate state — this is the most common way stale-value bugs hide
  from a single-pass manual test.
- The active filter state should be visible somewhere on screen (a subtitle, a pill, a summary)
  — a filtered dashboard that doesn't say what it's filtered to invites misreading a partial
  view as the full picture.

## When you can't verify

Say so. "UNVERIFIED — no source field found for X" in a QA report is more useful and more
trustworthy than silently shipping a number that might be wrong. Never round up confidence to
close out a QA pass faster.
