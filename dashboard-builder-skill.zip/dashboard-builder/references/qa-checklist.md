# QA checklist and workflow

Run this after the main build pass. The goal is one focused QA/fix pass, not open-ended
iteration — the dashboard is done when the final regression pass has no Critical finding.

## Stage 5 — Functional QA

Exercise every interactive element at least once:

- Every tab/nav item switches views correctly and the active tab state is visually correct.
- Every button (download, reset, close, toggle) does what it says and nothing else.
- Every filter (each individually, and at least two in combination) — see the filter contract in
  `data-integrity.md`.
- Reset/clear restores the exact original state.
- Dropdowns/panels open, close, and don't leave stray open state when switching tabs.
- Tooltips show on hover (and on tap, with a dismiss path, for touch) and don't get stuck open.
- Theme toggle switches every themed element correctly, both directions.
- Chart↔table toggles (if present) show equivalent data.
- Export/download (if present) produces a file with correct, current (filter-respecting) data.

## Stage 6 — Data QA

Full pass through `data-integrity.md`. Report format for findings:

`Location → current value → expected/source value → cause → minimal fix`

Bucket findings as **Critical** (wrong/fabricated/missing/stale/incorrectly-filtered),
**Inconsistent** (disagrees between two places on the dashboard), or note areas as **Clean**
once actually verified — don't mark something clean without recomputing it.

## Stage 7 — Responsive/UI QA

Render at the viewport matrix in `responsive-accessibility.md`. At each width, check: overflow,
clipping, wrapping, overlap, spacing/alignment consistency, chart readability, table behavior
(contained scroll, not page-breaking), icon/control consistency, header height, unexplained
whitespace, and theme correctness (repeat the pass in both light and dark, or at minimum spot
check dark at 2–3 widths).

## Stage 8 — Fix

Apply only justified fixes — i.e. ones that trace to an actual finding from stages 5–7, not
speculative polish. For each fix, note what broke it and what the fix addresses so the regression
pass (stage 9) knows what to re-check.

## Stage 9 — Regression

Re-verify, at minimum: desktop width, one intermediate width, mobile width, light theme, dark
theme, the filter(s) touched by any fix, and any calculation touched by any fix. A fix that isn't
regression-tested is not confirmed done.

## Browser automation

If a browser automation tool is available (Playwright, Puppeteer, or an MCP browser-control
tool), use it — actual rendered verification catches things static HTML/CSS reading misses
(computed heights, real overflow, real console errors). `scripts/dashboard-qa.js` is a
Playwright script covering the viewport sweep, screenshot capture, page-level horizontal-overflow
detection, and a console-error/uncaught-exception check; adapt its tab/filter selectors to the
dashboard you just built (they're marked as placeholders in the script).

If Playwright isn't available, use whatever browser tool the harness exposes (e.g. an MCP Chrome
tool) to do the same checks manually: resize/screenshot at a few key widths, click through tabs
and filters, read the console for errors. If no browser tool exists at all, do the closest manual
equivalent (open in a real browser and resize by hand) and say explicitly in your final report
that automated QA wasn't run and this needs manual verification before shipping.

## What "done" means

The final QA pass produced zero Critical findings. Inconsistent findings are resolved or, if
genuinely ambiguous (e.g. two legitimately different data bases for "the same" metric), labeled
clearly on the dashboard rather than silently picking one. Anything left UNVERIFIED is stated as
a limitation in the final summary to the user, not implied to be checked.
