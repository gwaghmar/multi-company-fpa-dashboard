# Responsive design and accessibility

## Breakpoint philosophy

One structural breakpoint (desktop vs. mobile/narrow-desktop) plus fluid `auto-fit`/`minmax()`
grids for KPI tiles and card rows handles most cases better than five fussy breakpoints. The
reference implementation uses a single `max-width: 1099px` mobile/narrow query and relies on
`grid-template-columns: repeat(auto-fit, minmax(150px, 1fr))` for tile bands so they reflow
without extra breakpoints. Add a second breakpoint only when a specific layout genuinely needs
it (e.g. a fixed multi-column analytical grid that has no fluid equivalent).

## Required viewport test matrix

Actually render the dashboard at these widths (not just read the CSS) before calling it done:

320, 375, 390, 430, 768, 1024, 1280, 1440, 1728, 1920 px.

Also test a **short** desktop window (e.g. 1440×700) — vertical cramping breaks fixed-height
chart rows just as often as narrow width does. Check intermediate widths (e.g. 900–1099px)
specifically around the mobile/desktop breakpoint boundary, since that's where flex/grid
direction changes are most likely to have an unhandled gap.

At each width, check for: horizontal overflow, clipped or truncated text/values, overlapping
elements, broken card heights, charts squeezed to unreadable size, tables that break the page
layout instead of scrolling within their own container, inconsistent spacing, header height
ballooning, and unexplained empty whitespace (usually a `min-height` bug — see
`design-system.md`'s pitfall note).

**WCAG 2.2 reflow**: content should work without horizontal scrolling of the whole page at
320px CSS width. Data tables and genuinely two-dimensional visualizations (wide tables, dense
charts) may use their own contained `overflow-x: auto` scroll region — that's the correct
pattern, not a violation. What's not acceptable is `body { overflow-x: hidden }` used to hide a
layout that actually overflows; find and fix the overflowing element instead. `overflow-x:
hidden` on `body` as a last-resort backstop (with the real fix applied to the specific offending
element) is fine; using it as the *only* fix is not.

## Mobile is a redesign, not a shrink

- Reorder for importance: most critical info first, supporting detail below — don't just stack
  the desktop DOM order and shrink font sizes.
- Simplify the header: brand + a scrollable tab strip (with an edge-fade mask and a "more this
  way" affordance) is usually enough; move secondary actions into an overflow area if needed.
  Never introduce a hamburger menu just to hide the same tabs desktop shows inline — a
  horizontally scrollable strip keeps navigation depth identical across breakpoints.
- Stack side-by-side chart+legend or chart+table pairs into a single column; make sure the
  stacked item that had `flex-grow` into a definite parent height on desktop gets a
  content-driven height override on mobile (a `flex: 1 1 auto` copied verbatim into a
  no-longer-constrained mobile layout is a common source of an oversized empty box).
- Filters become a full-width bottom sheet or full-screen panel, not a cramped dropdown.
- Increase base font size slightly (e.g. 13.5px → 14.5px) and bump KPI value size for
  readability without zoom.
- Any free-text input needs `font-size: 16px` on mobile — iOS Safari auto-zooms the page on
  focusing a smaller input, which is jarring in an app shell.
- Avoid nested scroll regions where possible; when unavoidable (a table inside a card inside a
  scrolling tab), make sure `overscroll-behavior: contain` is set so an inner scroll doesn't
  drag the outer page.

## Touch targets

Visible controls can stay visually compact (a dashboard's chrome should stay light), but the
*hit area* must be ≥ 40×40px (WCAG 2.2 AA target size, with some slack over the 24px minimum) on
touch. Use an absolutely-positioned pseudo-element with a negative inset to expand the hit area
without inflating the visible pill/icon — apply this uniformly to every small control (filter
pills, icon buttons, toggle buttons, close buttons), not just some of them.

## Accessibility checklist

- Semantic HTML: `nav`/`main`/`table`/`th`/heading levels used for their actual meaning, not
  divs styled to look like them.
- Keyboard: every interactive control (tabs, filter checkboxes, buttons, chart-table toggle) is
  reachable and operable via keyboard alone; visible focus states on all of them (don't strip
  `outline` without a replacement).
- Labels: form controls and icon-only buttons get `aria-label` or equivalent text; a checkbox
  filter list needs each row associated with its label, not just visually adjacent.
- Color is never the only signal: pair up/down/status color with a direction glyph, sign, or
  text — a colorblind reader must still get the message.
- Contrast: body text and KPI values should meet ~4.5:1 against their surface in both themes;
  muted/caption text can relax slightly but should still be legible, not decorative-only.
- Charts: since hand-rolled SVG charts are typically not screen-reader-navigable, the
  chart↔table toggle (see `dashboard-ux-rules.md`) is the accessibility fallback — treat it as
  required, not optional, for any chart carrying decision-relevant data.
- Motion: keep entrance animations short (~150–300ms) and respect `prefers-reduced-motion` by
  disabling or shortening them when set.

## Verifying without Playwright

If no browser automation tool is available, do a manual pass: open the file directly (it should
work from `file://` for a fully self-contained dashboard, or via a local static server if it
fetches a JSON data file), resize the window through the viewport matrix above, toggle the
theme, and exercise filters — this is a lower-confidence substitute for automated QA
(`scripts/dashboard-qa.js`), not a skip.
