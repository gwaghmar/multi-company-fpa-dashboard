# Design system — minimal enterprise

Generalized from a production FP&A dashboard. Every literal color, font family, and pixel value
below is a *default* for the "minimal enterprise" visual direction — swap the values, keep the
structure (token names, layout grammar, component contracts). Never hardcode a company's real
brand hex directly into a component rule; put it in the token block so theming stays centralized.

## Token set

Use semantic CSS custom properties, never literal colors in component rules.

```css
:root{
  color-scheme: light;
  /* surfaces */
  --page:#fafaf8; --surface:#ffffff; --surface-2:#f3f3f1;
  /* text */
  --ink:#111113; --ink-2:#5f5f66; --muted:#8a8a92;
  /* structure */
  --border:#e7e7ea; --border-strong:#d8d8dc;
  /* brand */
  --accent:#4a6cf7;
  /* status */
  --positive:#1f8a44; --negative:#d64545; --warning:#c07a1f; --info:#4a6cf7;
  /* fixed categorical series order — never reorder, never assign per-request */
  --series-1:#4a6cf7; --series-2:#db6434; --series-3:#1f8a44; --series-4:#6e56cf; --series-5:#808088;
}
:root[data-theme="dark"]{
  color-scheme: dark;
  --page:#0b0b0d; --surface:#161619; --surface-2:#1d1d21;
  --ink:#f4f4f6; --ink-2:#a8a8b0; --muted:#77777f;
  --border:#26262b; --border-strong:#3a3a41;
  --accent:#7b93ff;
  --positive:#4cc873; --negative:#ff6b5e; --warning:#e0a542; --info:#7b93ff;
  --series-1:#7b93ff; --series-2:#ff9e76; --series-3:#4cc873; --series-4:#a796f0; --series-5:#8e8e96;
}
@media (prefers-color-scheme: dark){
  :root:not([data-theme="light"]){ /* mirror the dark block above */ }
}
```

**Three-state theme contract** (light / dark / follow-system) — this is the part teams get wrong:

1. Define the full light palette on bare `:root`.
2. Redefine only the changed tokens under `@media (prefers-color-scheme: dark)`, scoped to
   `:root:not([data-theme="light"])` — so an explicit light choice always wins over system dark.
3. Redefine the same tokens again under `:root[data-theme="dark"]` — so an explicit dark choice
   wins regardless of system preference.
4. Never give a token its only definition inside a media query or `[data-theme]` block; every
   token needs a bare `:root` fallback or it's undefined when JS hasn't run yet.
5. A theme toggle only ever sets/removes `data-theme` on `<html>` — it never touches individual
   component styles.

If the brand requires more than one accent (e.g. a secondary CTA color), add `--accent-2`, don't
reuse a series color as a UI accent — series colors are reserved for chart data.

## Layout grammar (top to bottom)

This ordering is deliberate — it answers "what's happening → good or bad → why → where to look
next" before the reader has to think about it. Don't reorder based on decoration preferences.

1. **Topbar** — brand/product name, tab navigation, 1–2 global actions (theme toggle, export).
   Thin (~38–44px), sticky, one bottom border in `--ink` or `--border-strong` (not a shadow —
   shadows read as "floating," a data app's header should read as "anchored").
2. **Filter bar** — collapsed by default (a "Filters" pill + active-filter dot), expands to a
   panel. Never a permanently-open row of five dropdowns eating vertical space on every tab.
3. **Page/tab header** (`.vhead`) — tab title, one-line subtitle showing active filter state in
   prose ("FY26 · 3 quarters"), optional data-provenance badge, right-aligned actions
   (download, filters). Bottom border in `--ink`, thicker than card borders — this is the
   strongest structural line on the page after the topbar.
4. **KPI band** — 4–7 tiles max. Each tile: label (uppercase, small, muted) → value (large,
   tight tracking) → one delta line with direction color, never a bare number with no comparison.
   A KPI without a comparison ("vs budget," "vs prior period," "% of total") is incomplete.
5. **Primary chart/analysis row** — the one or two visuals that answer the tab's main question.
   Give this row a fixed or generous flex share; don't let it get squeezed by a `min-height`
   meant for the KPI tiles above it (see the min-height pitfall below).
6. **Commentary/driver row** (optional) — computed narrative sentences (largest driver, biggest
   variance, accuracy note) next to a supporting chart (waterfall, variance bars). Compute
   sentences from the same data arrays as the chart; never hand-write a number into prose.
7. **Supporting detail** — secondary charts, breakdowns, tables. Lowest visual weight; this is
   where an analyst drills in, not where an executive's eye should land first.
8. **Chart ↔ table toggle** (optional, recommended for accessibility) — every visualization gets
   an equivalent accessible table one click away, same data, same filter state.

## Core component contracts

Match these shapes; rename classes to fit the project's naming convention if one already exists.

- **Card** (`.card`): surface background, 1px `--border`, radius 14–18px, small padding
  (~9px 14px), a `h3` with a 2px top border in `--ink` (not the card's own border — a stronger
  rule than the card edge, so section headers read as headers). Cards never carry their own
  shadow; shadows are reserved for floating/overlay elements (dropdown panels, modals, tooltips).
- **KPI tile** (`.tile`): lighter than a card — thinner border, smaller radius, no header rule.
  Grid: `repeat(auto-fit, minmax(150–160px, 1fr))` so tiles reflow without a breakpoint.
- **Tab** (`.tab`): pill, transparent at rest, `--surface-2` on hover, `--ink` background +
  `--page` text when `aria-selected="true"`. Never use the accent color for tab selection — the
  accent is reserved for interactive/actionable state (buttons, active filters), not passive
  navigation state.
- **Filter pill / active-filter indicator**: outlined in `--accent` only when a non-default
  filter is applied; a small dot badge (not a text summary) is enough to signal "state changed."
  Long-form "what's filtered" text belongs in the tab subtitle and inside the filter panel, not
  crammed onto the pill itself.
- **Icon buttons / small pills**: visually ~15–16px tall is fine, but expand the *hit area* with
  a pseudo-element (`::after{content:"";position:absolute;inset:-10px}` or similar) so touch
  targets meet ~40×40px without inflating the visual footprint. Apply this trick consistently to
  every small control (filter pill, download button, chart-table toggle, close buttons) — a
  dashboard where only some small controls are touch-friendly reads as inconsistent, not just
  inaccessible.
- **Table**: sticky uppercase header in `--muted`/`--ink-2`, right-aligned numeric columns,
  left-aligned first column, `font-variant-numeric: tabular-nums` on data cells, a `tr.tot`
  variant (bold, top border in `--border-strong`) for totals rows.
- **Badge/disclosure note**: small pill, hollow (border + text color, no fill) for neutral
  provenance notes ("as filed, 9mo"); a colored dot prefix for status badges (data source,
  live/stale). Keep these low-contrast relative to real content — they're metadata, not KPIs.
- **Tooltip**: fixed-position, follows pointer, `--surface` background with `--ink` border (not
  a shadow-only floating box — a hairline border keeps it legible over any chart color
  underneath). On touch devices, tooltips need an explicit auto-hide timer and a
  scroll/touchstart-outside dismiss handler — "hover" literally doesn't exist there.

## Consistency rules (apply per semantic role, not per instance)

Group every repeated element by *purpose* and give that purpose exactly one visual treatment:

- Navigation icons/pills — one size, one interaction style, one selected-state treatment.
- Toolbar icon buttons — one height, one border/hover treatment, one hit-area expansion.
- KPI icons (if used at all — icons are optional, not required, on KPI tiles) — one size, one
  container shape, used only where they add scanning speed, never as decoration.
- Status/direction indicators (up/down/flat) — one glyph set, one color mapping, reused
  identically in KPI deltas, table cells, and chart annotations.
- Chevrons/disclosure carets — one size, one stroke width, everywhere they appear.

Audit before shipping: icon sizing, optical alignment, stroke width, control heights, card
padding, gaps, margins, type scale, radii, and border color — a one-off pixel value that isn't a
token is a bug, not a style choice, unless a comment explains the specific constraint forcing it
(see the `index.html` reference implementation for examples of documented exceptions — every
non-obvious value there has a comment explaining the layout bug it prevents).

## Minimal-enterprise restraint checklist

Avoid: gradients as a default surface treatment, oversized card padding/radii, hero-sized type
outside the page title, decorative icons with no semantic function, more than one accent color
doing interactive work, animated transitions beyond a short (~150–300ms) fade/rise on
view-enter, drop shadows on static content cards. Whitespace should come from the grid gap and
card padding tokens, not from ad hoc empty `<div>`s — an empty-looking card is almost always a
sizing bug (see the `min-height` pitfall below), not intentional breathing room.

## Known pitfall: shared `min-height` rules

A `min-height` written for one component category (e.g. "KPI/metric cards need at least 230px on
mobile so charts don't get crushed") will silently apply to *every* element sharing that class,
including text-only cards that should hug their content. Scope such rules with `:not()` to the
specific components that need them, or give the exception its own class. This is a real defect
class, not a hypothetical — verify computed height in the browser, not just the CSS source, when
a card looks like it has unexplained empty space.
