#!/usr/bin/env node
/**
 * dashboard-qa.js — Playwright-based responsive/functional smoke test for a dashboard built
 * with this skill. Not a replacement for the manual data-integrity pass in
 * references/data-integrity.md — this catches layout/console/overflow/NaN-class bugs across
 * the viewport matrix and does a light functional smoke test (tabs, filters, theme, reset).
 *
 * Usage:
 *   node dashboard-qa.js <url-or-file-path> [--screenshots-dir ./qa-screenshots]
 *
 * Requires Playwright (`npm i -D playwright` or `npx playwright install chromium` once).
 * If Playwright isn't available in this environment, don't install it just to run this script —
 * fall back to the manual checklist in references/qa-checklist.md and
 * references/responsive-accessibility.md using whatever browser tool the harness exposes.
 *
 * CUSTOMIZE the selectors in the SELECTORS block below to match the dashboard actually built —
 * they default to the class names used in assets/dashboard-shell.html.
 */

const path = require("path");
const fs = require("fs");

const SELECTORS = {
  tab: ".tab",
  filterButton: "#filterBtn, .filter-pill",
  filterCheckbox: '.filter-panel input[type="checkbox"]',
  filterReset: "#fpReset, .fp-reset",
  themeToggle: "#themeBtn",
};

const VIEWPORTS = [
  { name: "320", width: 320, height: 720 },
  { name: "375", width: 375, height: 812 },
  { name: "390", width: 390, height: 844 },
  { name: "430", width: 430, height: 932 },
  { name: "768", width: 768, height: 1024 },
  { name: "1024", width: 1024, height: 768 },
  { name: "1280", width: 1280, height: 800 },
  { name: "1440", width: 1440, height: 900 },
  { name: "1440-short", width: 1440, height: 700 }, // short desktop window — vertical cramping
  { name: "1728", width: 1728, height: 1080 },
  { name: "1920", width: 1920, height: 1080 },
];

async function main() {
  const args = process.argv.slice(2);
  const target = args[0];
  if (!target) {
    console.error("Usage: node dashboard-qa.js <url-or-file-path> [--screenshots-dir DIR]");
    process.exit(1);
  }
  const dirFlagIdx = args.indexOf("--screenshots-dir");
  const screenshotsDir = dirFlagIdx !== -1 ? args[dirFlagIdx + 1] : null;
  if (screenshotsDir) fs.mkdirSync(screenshotsDir, { recursive: true });

  let chromium;
  try {
    ({ chromium } = require("playwright"));
  } catch {
    console.error(
      "Playwright not found. Install it (`npm i -D playwright` then `npx playwright install chromium`) " +
        "or fall back to the manual checklist in references/qa-checklist.md."
    );
    process.exit(1);
  }

  const url = target.startsWith("http") ? target : `file://${path.resolve(target)}`;
  const browser = await chromium.launch();
  const findings = { critical: [], inconsistent: [], notes: [] };

  for (const theme of ["light", "dark"]) {
    for (const vp of VIEWPORTS) {
      const context = await browser.newContext({ viewport: { width: vp.width, height: vp.height } });
      const page = await context.newPage();
      const consoleErrors = [];
      page.on("console", (msg) => {
        if (msg.type() === "error") consoleErrors.push(msg.text());
      });
      page.on("pageerror", (err) => consoleErrors.push(String(err)));

      await page.goto(url, { waitUntil: "networkidle" }).catch((e) => {
        findings.critical.push(`[${theme}/${vp.name}] page failed to load: ${e.message}`);
      });

      if (theme === "dark") {
        await page.evaluate(() => {
          document.documentElement.setAttribute("data-theme", "dark");
          const btn = document.querySelector("#themeBtn");
          if (btn && /dark/i.test(btn.textContent || "")) btn.click();
        }).catch(() => {});
        await page.waitForTimeout(150);
      }

      // 1. Page-level horizontal overflow (the WCAG 2.2 reflow check).
      const overflow = await page.evaluate(() => {
        const doc = document.documentElement;
        return { scrollW: doc.scrollWidth, clientW: doc.clientWidth };
      });
      if (overflow.scrollW > overflow.clientW + 1) {
        findings.critical.push(
          `[${theme}/${vp.name}] horizontal page overflow: scrollWidth ${overflow.scrollW} > clientWidth ${overflow.clientW}`
        );
      }

      // 2. Visible NaN/undefined/Infinity/null leaking into rendered text.
      const badText = await page.evaluate(() => {
        const re = /\bNaN\b|\bundefined\b|\bInfinity\b|\bnull\b/;
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
        const hits = [];
        let node;
        while ((node = walker.nextNode())) {
          if (re.test(node.textContent) && node.textContent.trim().length < 200) {
            hits.push(node.textContent.trim());
          }
        }
        return hits.slice(0, 10);
      });
      if (badText.length) {
        findings.critical.push(`[${theme}/${vp.name}] unformatted value(s) visible in DOM: ${badText.join(" | ")}`);
      }

      if (screenshotsDir) {
        await page.screenshot({
          path: path.join(screenshotsDir, `${theme}-${vp.name}.png`),
          fullPage: true,
        }).catch(() => {});
      }

      if (consoleErrors.length) {
        findings.critical.push(`[${theme}/${vp.name}] console errors: ${consoleErrors.slice(0, 5).join(" | ")}`);
      }

      await context.close();
    }
  }

  // Functional smoke test at one representative desktop size, light theme only.
  {
    const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
    const page = await context.newPage();
    await page.goto(url, { waitUntil: "networkidle" }).catch(() => {});

    const tabs = await page.$$(SELECTORS.tab);
    if (!tabs.length) {
      findings.notes.push(`No elements matched tab selector "${SELECTORS.tab}" — update SELECTORS in this script.`);
    } else {
      for (const tab of tabs) {
        await tab.click().catch(() => {});
        await page.waitForTimeout(150);
      }
      findings.notes.push(`Clicked through ${tabs.length} tab(s) without a page crash.`);
    }

    const filterBtn = await page.$(SELECTORS.filterButton);
    if (filterBtn) {
      await filterBtn.click().catch(() => {});
      await page.waitForTimeout(150);
      const checkboxes = await page.$$(SELECTORS.filterCheckbox);
      if (checkboxes.length) {
        const before = await page.evaluate(() => document.body.innerText);
        await checkboxes[0].click().catch(() => {});
        await page.waitForTimeout(150);
        const after = await page.evaluate(() => document.body.innerText);
        if (before === after) {
          findings.inconsistent.push(
            "Toggling the first filter checkbox produced no visible change in page text — filter may not be wired to re-render."
          );
        }
        const resetBtn = await page.$(SELECTORS.filterReset);
        if (resetBtn) {
          await resetBtn.click().catch(() => {});
          await page.waitForTimeout(150);
          const afterReset = await page.evaluate(() => document.body.innerText);
          if (afterReset !== before) {
            findings.inconsistent.push("Reset did not restore the exact pre-filter page text.");
          }
        } else {
          findings.notes.push(`No reset control matched "${SELECTORS.filterReset}".`);
        }
      } else {
        findings.notes.push(`No filter checkboxes matched "${SELECTORS.filterCheckbox}".`);
      }
    } else {
      findings.notes.push(`No filter button matched "${SELECTORS.filterButton}".`);
    }

    const themeBtn = await page.$(SELECTORS.themeToggle);
    if (themeBtn) {
      const before = await page.evaluate(() => document.documentElement.getAttribute("data-theme"));
      await themeBtn.click().catch(() => {});
      await page.waitForTimeout(150);
      const after = await page.evaluate(() => document.documentElement.getAttribute("data-theme"));
      if (before === after) {
        findings.inconsistent.push("Theme toggle click did not change the data-theme attribute.");
      }
    } else {
      findings.notes.push(`No theme toggle matched "${SELECTORS.themeToggle}".`);
    }

    await context.close();
  }

  await browser.close();

  console.log("\n=== dashboard-qa.js report ===\n");
  console.log(`Target: ${url}`);
  console.log(`\nCritical (${findings.critical.length}):`);
  findings.critical.forEach((f) => console.log(`  - ${f}`));
  console.log(`\nInconsistent (${findings.inconsistent.length}):`);
  findings.inconsistent.forEach((f) => console.log(`  - ${f}`));
  console.log(`\nNotes (${findings.notes.length}):`);
  findings.notes.forEach((f) => console.log(`  - ${f}`));
  if (screenshotsDir) console.log(`\nScreenshots saved to ${screenshotsDir}`);
  console.log(
    "\nThis script does NOT verify data correctness (source→calculation→displayed value) — " +
      "that requires the manual pass in references/data-integrity.md against the real data model."
  );

  process.exit(findings.critical.length ? 1 : 0);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
